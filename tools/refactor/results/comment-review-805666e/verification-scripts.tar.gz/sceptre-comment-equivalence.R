root <- '/Users/ekatsevi/code/research/sceptre'
setwd(root)
base <- '805666e'
files <- system2('git', c('diff', '--name-only', base), stdout = TRUE)
files <- files[grepl('\\.R$', files)]
for (path in files) {
 old <- system2('git', c('show', paste0(base, ':', path)), stdout = TRUE)
 stopifnot(identical(parse(text = old, keep.source = FALSE),
                     parse(path, keep.source = FALSE)))
}
cat('Identical executable R expressions in', length(files), 'changed R files\n')
cat('roxygen2 available:', requireNamespace('roxygen2', quietly = TRUE), '\n')
