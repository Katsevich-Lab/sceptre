from pathlib import Path
import runpy, json, subprocess
namespace=runpy.run_path('/private/tmp/verify-sceptre-comment-pass.py')
lex=namespace['clang_tokens']; work=namespace['work']
p=work/'lexer-control.cpp'
p.write_text('int example = 1; // one\n')
a=lex(p)
p.write_text('// clearer explanation\nint example = 1;\n')
assert lex(p)==a
p.write_text('int example = 2;\n')
assert lex(p)!=a
p.write_text('const char* example = "one";\n')
b=lex(p)
p.write_text('const char* example = "two";\n')
assert lex(p)!=b
r=subprocess.run(['Rscript','--vanilla','-e', '''same <- function(a, b) identical(parse(text = a, keep.source = FALSE), parse(text = b, keep.source = FALSE)); stopifnot(same("x <- 1 # one", "# clear comment\\nx <- 1"), !same("x <- 1", "x <- 2"), !same("x <- 'one'", "x <- 'two'")); cat("R checker controls passed\\n")'''],capture_output=True,text=True)
assert r.returncode==0,r.stderr
report=json.loads((work/'validation.json').read_text())
report['checker_controls']={'comment_only_edits_accepted_in_R_and_C++':True,'numeric_code_edits_detected_in_R_and_C++':True,'string_code_edits_detected_in_R_and_C++':True,'clang_output_fully_parsed':True}
(work/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Checker controls passed: comment edits accepted; number/string edits detected.')
