from pathlib import Path
import subprocess,re,json,hashlib
root=Path('/Users/ekatsevi/code/research/sceptre'); base='805666e'
work=Path('/private/tmp/sceptre-comment-verification');work.mkdir(exist_ok=True)
sha=lambda b: hashlib.sha256(b).hexdigest()
files=subprocess.check_output(['git','diff','--name-only',base],cwd=root,text=True).splitlines()
def clang_tokens(path):
 r=subprocess.run(['clang','-x','c++','-fsyntax-only','-Xclang','-dump-raw-tokens',str(path)],capture_output=True,text=True)
 assert r.returncode==0,(path,r.stderr[-1000:])
 # Clang records can span lines (e.g. whitespace or a block comment).
 pattern=r"(\w+) '(.*?)'\t[^\n]*Loc=<[^\n]*>\n?"
 records=re.findall(pattern,r.stderr,re.S)
 assert not re.sub(pattern,'',r.stderr,flags=re.S).strip(), (path,'unparsed Clang output')
 assert records,(path,'no lexer records')
 out=[]
 for kind,value in records:
  if kind=='comment': continue
  if kind=='unknown' and not value.strip(): continue
  out.append((kind,value))
 return out
report={'base_commit':subprocess.check_output(['git','rev-parse',base],cwd=root,text=True).strip(),'cpp_files':{},'R_files':{},'published_roxygen_blocks_unchanged':True}
for name in files:
 old=subprocess.check_output(['git','show',base+':'+name],cwd=root)
 new=(root/name).read_bytes()
 if name.endswith(('.cpp','.h')):
  before=work/('before-'+Path(name).name);before.write_bytes(old)
  a=clang_tokens(before);b=clang_tokens(root/name)
  assert a==b,(name,'C++ tokens changed')
  directives=lambda s: re.findall(rb'^\s*//\s*\[\[Rcpp::.*$',s,re.M)
  assert directives(old)==directives(new),(name,'Rcpp directives changed')
  report['cpp_files'][name]={'before_sha256':sha(old),'after_sha256':sha(new),'tokens':len(a),'token_sha256':sha(json.dumps(a).encode()),'Rcpp_directives_unchanged':True}
 elif name.endswith('.R'):
  report['R_files'][name]={'before_sha256':sha(old),'after_sha256':sha(new)}
  if name.startswith('R/'):
   blocks=lambda s:[b for b in re.findall(rb"(?:^\s*#'[^\n]*\n)+",s,re.M) if b'@noRd' not in b]
   assert blocks(old)==blocks(new),(name,'published roxygen changed')
 else: continue
r=subprocess.run(['Rscript','--vanilla','/private/tmp/sceptre-comment-equivalence.R'],cwd=root,capture_output=True,text=True)
assert r.returncode==0,r.stderr
report['R_expression_comparison']=r.stdout.strip()
report['cpp_lexing']='Clang raw tokens match exactly after excluding comments and whitespace; Rcpp attribute comments checked separately'
report['R_expression_comparison_passed']=True
report['files_checked']=len(report['cpp_files'])+len(report['R_files'])
report['clang_version']=subprocess.check_output(['clang','--version'],text=True).splitlines()[0]
report['remaining_limits']='No numerical/runtime/resource rerun: this verifies unchanged executable expressions/tokens and published documentation, not broader statistical claims.'
(work/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'R_files':len(report['R_files']),'cpp_files':len(report['cpp_files']),'R_AST':'identical','C++_tokens':'identical','Rcpp_attributes':'unchanged','published_roxygen':'unchanged'},indent=2))
