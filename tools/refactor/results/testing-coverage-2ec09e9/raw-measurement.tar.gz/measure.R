args<-commandArgs(trailingOnly=TRUE)
source<-normalizePath(args[[1L]],mustWork=TRUE)
out<-normalizePath(args[[2L]],mustWork=TRUE)
.libPaths(c("/private/tmp/sceptre-rf0-ondisc-library",.libPaths()))
stopifnot(identical(as.character(utils::packageVersion("ondisc")),"1.3.5"))
Sys.unsetenv(c("SCEPTRE_REFACTOR_ORACLE","SCEPTRE_REFACTOR_ORACLE_DEBUG"))
Sys.setenv(CI="true", SCEPTRE_REQUIRE_ONDISC="true")
for (name in c("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS")) do.call(Sys.setenv,stats::setNames(list("1"),name))
# Instrument R expressions only. Native code is freshly built with its ordinary
# flags; no --coverage flags and no native-code percentage are requested.
options(covr.flags=character())
coverage<-covr::package_coverage(source,type="tests",clean=FALSE,quiet=FALSE,
                               install_path=file.path(out,"library"))
saveRDS(coverage,file.path(out,"coverage.rds"))
tally<-covr::tally_coverage(coverage,by="line")
stopifnot(all(grepl("^R/.*[.]R$",tally$filename)),
          !length(list.files(file.path(source,"src"),"[.]gcno$",recursive=TRUE)),
          !length(list.files(file.path(out,"library"),"[.]Rout[.]fail$",recursive=TRUE)))
write.csv(tally,file.path(out,"lines.csv"),row.names=FALSE)
by_file<-do.call(rbind,lapply(split(tally,tally$filename),function(d) {
 data.frame(file=d$filename[[1L]],lines=nrow(d),covered=sum(d$value>0),
            percent=100*mean(d$value>0))
}))
write.csv(by_file,file.path(out,"files.csv"),row.names=FALSE)
routs<-list.files(file.path(out,"library"),"testthat[.]Rout$",recursive=TRUE,full.names=TRUE)
stopifnot(length(routs)==1L)
result<-list(scope="R executable-line coverage under each revision's own package tests; C++ is not instrumented",
 covered=sum(tally$value>0),executable_lines=nrow(tally),percent=100*mean(tally$value>0),
 reported_by_covr=covr::percent_coverage(coverage),files=length(unique(tally$filename)),
 covr=as.character(utils::packageVersion("covr")),generated_wrappers="covr standard R/RcppExports.R exclusion",
 test_output=routs,test_tail=tail(readLines(routs),20L),session=capture.output(sessionInfo()))
stopifnot(identical(result$percent,result$reported_by_covr))
jsonlite::write_json(result,file.path(out,"summary.json"),pretty=TRUE,auto_unbox=TRUE,digits=NA)
cat(result$covered,"/",result$executable_lines,"R lines:",result$percent,"percent\n")
