#!/usr/bin/env python3
"""Append explicitly handed-off final evidence; preserve source files and CAS dependencies."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,sys
root=Path(__file__).resolve().parent;m=json.loads((root/'manifest.json').read_text())
base=Path('/private/tmp/sceptre-pre-air-evidence-content');consumer=Path('/private/tmp/sceptre-final-consumers-0a9f9d8-additive-content')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
bi={e['sha256']:e['bytes'] for e in json.loads((base/'manifest.json').read_text())['files']}
ci={e['sha256']:e['bytes'] for e in json.loads((consumer/'manifest.json').read_text())['files'] if e['store']=='additive'}
items=json.loads(sys.argv[1]);added=[]
# Align the current guide's intended results/final-0a9f9d8/maintainability link.
for e in m['files']:
 if e['path'].startswith('maintainability0a/'):e['path']='maintainability/'+e['path'].removeprefix('maintainability0a/')
for prefix,src in items:
 source=Path(src);assert source.exists()
 pairs=[(source,prefix)] if source.is_file() else [(p,prefix+'/'+str(p.relative_to(source))) for p in sorted(source.rglob('*')) if p.is_file()]
 for p,target in pairs:
  assert not p.is_symlink();s=p.stat();digest=sha(p)
  assert p.stat().st_size==s.st_size and p.stat().st_mtime_ns==s.st_mtime_ns
  existing=[e for e in m['files'] if e['path']==target]
  if existing:
   assert existing[0]['sha256']==digest and existing[0]['mtime_ns']==s.st_mtime_ns,('Would replace evidence',target)
   continue
  if digest in bi:store='historical';obj=base/'blobs'/digest
  elif digest in ci:store='consumer';obj=consumer/'blobs'/digest
  else:
   store='final';obj=root/'blobs'/digest
   if not obj.exists():shutil.copyfile(p,obj)
  assert sha(obj)==digest
  e=dict(path=target,original_path=str(p),mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,bytes=s.st_size,sha256=digest,store=store)
  m['files'].append(e);added.append(target)
m['files'].sort(key=lambda e:e['path']);assert len({e['path'] for e in m['files']})==len(m['files'])
m['ci_status']='Final six-job success logs and initial network failure retained; awaiting quiet-receipt erratum and postqualification documentation before archive.'
(root/'manifest.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
p=root/'supplement-history.json';history=json.loads(p.read_text()) if p.exists() else []
history.append(dict(at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs=items,added=added))
p.write_text(json.dumps(history,indent=2)+'\n')
print('Added',len(added),'paths; total',len(m['files']))
