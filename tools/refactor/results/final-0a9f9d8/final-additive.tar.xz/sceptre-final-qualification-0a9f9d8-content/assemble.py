#!/usr/bin/env python3
"""Stage final0a qualification metadata/raw evidence, reusing two immutable CAS dependencies."""
from pathlib import Path
import collections,datetime,hashlib,json,os,shutil,stat
TMP=Path('/private/tmp');stage=TMP/'sceptre-final-qualification-0a9f9d8-content'
base=TMP/'sceptre-pre-air-evidence-content';consumer=TMP/'sceptre-final-consumers-0a9f9d8-additive-content'
assert not stage.exists();stage.mkdir();(stage/'blobs').mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
assert sha(base/'manifest.json')=='ca71cc66ad9d4635378be43693b823d071771cf13601132d183dfea39bd37603'
assert sha(consumer/'manifest.json')=='087a70f69735ead5567e616ac60a5132a30ce249bf9d96a93df821d184dc088a'
bm=json.loads((base/'manifest.json').read_text());cm=json.loads((consumer/'manifest.json').read_text())
base_index={e['sha256']:e['bytes'] for e in bm['files']}
consumer_index={e['sha256']:e['bytes'] for e in cm['files'] if e['store']=='additive'}
files=[];excluded=[];links=[]
def reason(group,rel):
 p=rel.parts
 if group=='final0a':
  if len(p)>=2 and p[0]=='candidate' and p[1] in ('source','library'):
   return 'Extracted full Git source duplicate; exact compiled source/tools and archive SHA retained' if p[1]=='source' else 'Compiled installed library; source/build/DLL fingerprints retained'
  if str(rel) in ('candidate/source.tar','candidate/check/immutable-source.tar'):
   return 'Full Git website/history archive container not repeated; SHA/pin retained; actual built R package tarball retained'
  if len(p)>=3 and p[0]=='candidate' and p[1] in ('check','check-aligned'):
   if p[2]=='source':return 'Extracted source duplicate; archive identity and built R package tarball retained'
   if len(p)>=4 and p[2]=='sceptre.Rcheck' and p[3] in ('00_pkg_src','sceptre'):
    return 'Disposable Rcheck extracted/installed cache; logs, test outputs and built R package tarball retained'
 if rel.suffix in ('.o','.so','.dll','.dylib','.a') or any(v.endswith('.dSYM') for v in p):return 'Compiled object/shared library excluded; source/build fingerprints retained'
 return None

def add(path,target,group,why=None):
 s=path.lstat();meta=dict(mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,bytes=s.st_size)
 if why:
  e=dict(path=target,original_path=str(path),reason=why,**meta)
  if path.suffix in ('.tar','.gz') and path.is_file():e['sha256']=sha(path)
  excluded.append(e);return
 if path.is_symlink():links.append(dict(path=target,target=os.readlink(path),original_path=str(path),**meta));return
 assert path.is_file(),str(path)
 digest=sha(path)
 assert path.stat().st_size==s.st_size and path.stat().st_mtime_ns==s.st_mtime_ns
 if digest in base_index:
  assert base_index[digest]==s.st_size;store='historical';obj=base/'blobs'/digest
 elif digest in consumer_index:
  assert consumer_index[digest]==s.st_size;store='consumer';obj=consumer/'blobs'/digest
 else:
  store='final';obj=stage/'blobs'/digest
  if not obj.exists():shutil.copyfile(path,obj)
 assert sha(obj)==digest
 files.append(dict(path=target,original_path=str(path),sha256=digest,store=store,**meta))
roots=[('final0a',TMP/'sceptre-final-0a9f9d8'),('air',TMP/'sceptre-air-style-2ab3f5a'),('air-independent',TMP/'sceptre-air-style-independent'),('maintainability0a',TMP/'sceptre-maintainability-final-0a9f9d8-6udr1nlw'),('bioc0a',TMP/'sceptre-bioccheck-final-0a9f9d8-evidence')]
for group,root in roots:
 assert root.is_dir()
 for current,ds,fs in os.walk(root,followlinks=False):
  current=Path(current)
  for name in ds[:]:
   path=current/name
   if path.is_symlink():add(path,group+'/'+str(path.relative_to(root)),group,reason(group,path.relative_to(root)));ds.remove(name)
  for name in fs:
   path=current/name;rel=path.relative_to(root);add(path,group+'/'+str(rel),group,reason(group,rel))
# Exact original finalconsumer file set, reused by hash rather than embedded again.
for e in cm['files']:
 store='historical' if e['store']=='base' else 'consumer'
 files.append(dict(e,path='consumers0a/'+e['path'],store=store,original_path='immutable final-consumer CAS manifest:'+e['path']))
# Full compile inputs and handwritten top-level qualification tools without nested history archives.
build=json.loads((TMP/'sceptre-final-0a9f9d8/candidate/build.json').read_text());assert build['source_commit']=='0a9f9d879db6a52e3daef237daa1711b9d542976'
source=Path(build['source'])
for name,expected in build['source_file_git_blobs'].items():
 body=(source/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==expected
 add(source/name,'compiled-source/'+name,'compiled-source')
for path in sorted((source/'tools/refactor').iterdir()):
 if path.is_file():add(path,'qualification-tools/'+path.name,'tools')
for path in sorted((source/'.github/workflows').glob('*')):
 if path.is_file():add(path,'qualification-source/.github/workflows/'+path.name,'tools')
# Reused fixed resource data are materialized from the historical CAS with explicit authority.
for e in bm['files']:
 if e['path'].startswith('final32/resource-data/'):
  files.append(dict(e,path='resource-inputs/'+e['path'].removeprefix('final32/resource-data/'),store='historical',original_path='historical CAS:'+e['path']))
extras=['sceptre-final-0a9f9d8-build-driver.log','sceptre-final-0a9f9d8-prepare.log','sceptre-final-0a9f9d8-qualification-driver.log','sceptre-final-0a9f9d8-targeted-attempt1-invalidated-driver.log','sceptre-final-0a9f9d8-targeted-driver.log','sceptre-maintainability-final-0a9f9d8-6udr1nlw-bundle.json','sceptre-final-consumers-0a9f9d8-quiet-completion.json']
for name in extras:add(TMP/name,'receipts-and-drivers/'+name,'extra')
for label,p in [('consumer',TMP/'sceptre-final-consumers-0a9f9d8-additive-verification/receipt.json'),('historical-recompression',TMP/'sceptre-pre-air-evidence-dict256-verification/receipt.json')]:add(p,'dependency-receipts/'+label+'.json','extra')
assert len({e['path'] for e in files})==len(files)
assert not links,('Symlink requires explicit handling',links)
binding=json.loads((TMP/'sceptre-final-0a9f9d8/air-integration-binding.json').read_text())
assert binding['independent_review_sha256']==sha(TMP/'sceptre-air-style-independent/review.md')
notes=['Final production0a only; historical32/pre-Air2ab data retain original pins and conclusions in dependency base.',
 'Final0a general timing is a targeted48-process repeat, not a fresh160-process final0a matrix; the complete2ab160-process matrix is retained in the historical base.',
 'First targeted attempt was invalidated and is retained separately. Diagnostic borrowed-triplet variant deliberately restores caller mutation and is neither production nor a safe remedy/exception proof.',
 'Resource outcomes/dispositions must be read from their raw reports; this archive does not transform a threshold crossing into a pass.',
 'Historical/pre-Air CAS and final-consumer additive CAS are required dependencies and are not embedded as redundant archives.',
 'All1,149 finalconsumer payload paths are restored via the required stores; original21 outputs were reused, not re-executed.',
 'Actual built R package tarball retained; duplicate full Git website/history tar containers and extracted sources omitted with SHA/pin metadata. All compiled productionR/src/NAMESPACE/DESCRIPTION bytes are retained.',
 'Installed libraries, compiled objects and disposable check caches excluded; DLL/compiler/source fingerprints, all check logs/tests/example outputs/native transforms retained.',
 'No new R/build/benchmark/consumer execution occurred to assemble this evidence. Final CI logs may be appended before compression.']
dump(stage/'exclusions.json',dict(notes=notes,files=excluded))
manifest=dict(schema_version=1,production_pin=build['source_commit'],reference_pin='21f9ea098b69c444a884a49bc254de711968e3b5',
 created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Final0a raw qualification evidence plus explicitly dependent historical and consumer authority; read retained limits and failures.',
 dependencies=dict(historical=dict(manifest_sha256=sha(base/'manifest.json'),control_manifest_sha256=sha(base/'control-manifest.json')),consumer=dict(manifest_sha256=sha(consumer/'manifest.json'),control_manifest_sha256=sha(consumer/'control-manifest.json'))),
 files=sorted(files,key=lambda e:e['path']),exclusions_sha256=sha(stage/'exclusions.json'),ci_status='Awaiting root final CI log handoff before final archive')
dump(stage/'manifest.json',manifest);shutil.copy2(Path(__file__),stage/'assemble.py')
print(json.dumps(dict(stage=str(stage),files=len(files),counts=dict(collections.Counter(e['store'] for e in files)),groups=dict(collections.Counter(e['path'].split('/')[0] for e in files)),new_blobs=len(list((stage/'blobs').iterdir())),new_blob_bytes=sum(p.stat().st_size for p in (stage/'blobs').iterdir()),exclusions=len(excluded),manifest_sha256=sha(stage/'manifest.json')),indent=2))
