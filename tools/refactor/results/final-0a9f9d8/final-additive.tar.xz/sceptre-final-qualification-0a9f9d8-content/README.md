# Final0a SCEPTRE qualification evidence

This additive content store preserves raw evidence for frozen production `0a9f9d879db6a52e3daef237daa1711b9d542976` against original `21f9ea098b69c444a884a49bc254de711968e3b5`. It depends on two existing immutable archives and does not embed them again:

- Historical/pre-Air: `sceptre-pre-air-evidence-content-dict256.tar.xz`, SHA256`7f4a2eaaacf43113e472bfb9dc8926e379f0a8eab60f36b70360781cff5e055e` (53,283,280bytes). Its exact manifest is`ca71cc66ad9d4635378be43693b823d071771cf13601132d183dfea39bd37603`.
- Final consumer: `sceptre-final-consumers-0a9f9d8-additive.tar.xz`, SHA256`bc1d0db1928f44021d9c583b9a4ecf59e6a414280b44bd921e492fe032fafe97` (1,065,520bytes). Its exact manifest is`087a70f69735ead5567e616ac60a5132a30ce249bf9d96a93df821d184dc088a`.

After extracting all three archives:

```
python3 restore.py HISTORICAL_CONTENT_DIRECTORY CONSUMER_CONTENT_DIRECTORY /fresh/output
python3 restore.py HISTORICAL_CONTENT_DIRECTORY CONSUMER_CONTENT_DIRECTORY /fresh/output --verify-only
```

Only Python standard library is required. The tool checks both exact dependency manifest/control hashes, every required dependency blob, every new blob, all output bytes/modes/nanosecond mtimes, the full1,149-file consumer payload set and the Bioc/maintainability bundles' own payload manifests. It creates independent files, not hardlinks. No original absolute path, R installation, network, compiled DLL or source checkout is required for reconstruction.

## Scope and limits

`final0a/` retains installed/native/package-build/check outputs, the complete targeted48-process timing study, its invalidated first attempt, launch/exit/quiet receipts, and the separate triplet-memory diagnostic including raw profiles, control/variant source and exact commands. Final0a did **not** repeat the complete160-process matrix; that pre-Air2ab study remains in the historical dependency, with signed source/carry proof. Threshold crossings, failures and invalidations remain raw and are not relabeled as passes. The borrowed-triplet diagnostic deliberately restores historical caller mutation, is not production and does not establish a safe remedy, an unavoidable minimum or an accepted exception.

`air/`, `air-independent/` and `compiled-source/` preserve Air before/after/patch/AST/idempotence/roxygen/review/binding authority and every actual compiled productionR/src/NAMESPACE/DESCRIPTION byte. `qualification-tools/` preserves the exact top-level tools used by the tests/probes/workers. Full Git archive website/history containers and extracted source duplicates are excluded with SHA/pin metadata; the actual built R package tarball is retained. Installed libraries/compiled objects/disposable check caches are excluded with precise file records; build/DLL/compiler/source identities and raw checks/tests/example outputs/native transformations remain.

`maintainability/` and `bioc0a/` retain their complete current payloads, raw reports, producer/tool/runtime/dependency authority and limitations. `consumers0a/` reproduces every file of the separately verified final-consumer bundle through the same CAS dependencies. Its30 actual stages and complete standard/nuclear fair shared-arrival Nextflow pass; all three ordered payload families match the reused original exactly. The inherited empty-barcode book error/exit1 remains14/15, not whole-book success. Original reference outputs were verified/reused, not re-executed.

`resource-inputs/` explicitly reuses fixed historical data. `dependency-receipts/` preserves prior reconstruction receipts. Exact per-file exclusions are in `exclusions.json`; `manifest.json` is the authoritative selection and names all source stores. Raw result interpretation and final acceptance/disposition belong to the retained reports and root acceptance matrix. This evidence assembly does not create scientific or performance results. No R, build, benchmark, consumer runtime or production edit was performed to construct it.

## Final handoff additions

The final six successful CI logs and initial network failure are retained under `final0a/ci-final*`. The original targeted quiet-start false-clear receipt remains unchanged; `targeted-attempt1-ERRATUM.json` corrects it, and the affected attempt remains invalidated. Final quiet-end and maintainability-guide-update snapshots are retained. User decision D2026-10-16-04 accepting the measured bounded Papalexi whole-workflow cold-serial RSS cost is recorded in ordinary tracked repo documentation alongside this archive; this is separate from the raw threshold test and does not prove an unavoidable minimum. The independent triplet diagnostic interpretation is retained unchanged under `independent-diagnostic-interpretation/`. These postqualification documents are identified separately from frozen production source.
