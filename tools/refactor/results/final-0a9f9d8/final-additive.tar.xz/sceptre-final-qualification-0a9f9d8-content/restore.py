#!/usr/bin/env python3
"""Restore final0a qualification with both exact immutable content-store dependencies.
Usage: python3 restore.py HISTORICAL_CONTENT CONSUMER_CONTENT FRESH_OUTPUT
       python3 restore.py HISTORICAL_CONTENT CONSUMER_CONTENT OUTPUT --verify-only
Python standard library only. Verifies required base blobs; creates no hardlinks.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,shutil,stat

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def safe(v):
 p=PurePosixPath(v)
 if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('Unsafe path: '+v)
 return Path(*p.parts)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('historical',type=Path);parser.add_argument('consumer',type=Path);parser.add_argument('destination',type=Path);parser.add_argument('--verify-only',action='store_true');a=parser.parse_args()
 root=Path(__file__).resolve().parent;m=json.loads((root/'manifest.json').read_text());assert m['schema_version']==1
 for e in json.loads((root/'control-manifest.json').read_text())['files']:assert sha(root/safe(e['path']))==e['sha256']
 assert sha(root/'exclusions.json')==m['exclusions_sha256']
 stores=dict(historical=a.historical.resolve(),consumer=a.consumer.resolve(),final=root)
 manifests={}
 for key in ['historical','consumer']:
  dependency=m['dependencies'][key];p=stores[key]
  assert sha(p/'manifest.json')==dependency['manifest_sha256'],'Wrong/mutated '+key+' manifest.'
  assert sha(p/'control-manifest.json')==dependency['control_manifest_sha256'],'Wrong/mutated '+key+' control manifest.'
  manifests[key]=json.loads((p/'manifest.json').read_text())
 assert manifests['consumer']['base_manifest_sha256']==m['dependencies']['historical']['manifest_sha256']
 indexes=dict(historical={e['sha256']:e['bytes'] for e in manifests['historical']['files']},consumer={e['sha256']:e['bytes'] for e in manifests['consumer']['files'] if e['store']=='additive'})
 required={}
 for key in stores:
  required[key]={e['sha256']:e['bytes'] for e in m['files'] if e['store']==key}
  if key!='final':assert all(indexes[key][h]==size for h,size in required[key].items())
  else:assert {p.name for p in (root/'blobs').iterdir()}==set(required[key])
  for digest,size in required[key].items():
   p=stores[key]/'blobs'/digest;assert p.is_file() and p.stat().st_size==size and sha(p)==digest,'Missing/mutated '+key+' object.'
 files=m['files'];assert len({e['path'] for e in files})==len(files)
 for e in files:safe(e['path']);assert e['mode']&0o7000==0
 dest=a.destination.resolve()
 if not a.verify_only:
  if dest.exists() and any(dest.iterdir()):raise ValueError('Destination must be fresh and empty.')
  dest.mkdir(parents=True,exist_ok=True)
  for e in files:
   p=dest/safe(e['path']);p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stores[e['store']]/'blobs'/e['sha256'],p);p.chmod(e['mode']);os.utime(p,ns=(e['mtime_ns'],e['mtime_ns']))
 actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file() or p.is_symlink()}
 assert actual=={e['path'] for e in files}
 for e in files:
  p=dest/safe(e['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  assert s.st_size==e['bytes'] and sha(p)==e['sha256'] and stat.S_IMODE(s.st_mode)==e['mode'] and s.st_mtime_ns==e['mtime_ns'],e['path']
 # The entire separately qualified consumer set must be present unchanged.
 consumer={e['path'].removeprefix('consumers0a/'):e for e in files if e['path'].startswith('consumers0a/')}
 assert len(consumer)==len(manifests['consumer']['files'])
 for e in manifests['consumer']['files']:
  actual=consumer[e['path']];assert all(actual[k]==e[k] for k in ['bytes','sha256','mode','mtime_ns'])
 # Verify the bundles' own internal payload manifests as additional authority.
 inner_counts={}
 for group,name in [('bioc0a','manifest.json'),('maintainability','artifact-manifest.json'),('final0a/ci-final','manifest.json')]:
  inner=json.loads((dest/group/name).read_text())
  if 'files' in inner:
   entries=inner['files']
   for e in entries:
    p=dest/group/safe(e['path']);assert p.is_file() and p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
   inner_counts[group]=len(entries)
  else:
   for path,digest in inner['sha256'].items():assert sha(dest/group/safe(path))==digest
   inner_counts[group]=len(inner['sha256'])
 binding=json.loads((dest/'final0a/air-integration-binding.json').read_text());assert binding['integration_commit']==m['production_pin'] and sha(dest/'air-independent/review.md')==binding['independent_review_sha256']
 print(json.dumps(dict(verified=True,production_pin=m['production_pin'],files_verified=len(files),required_blob_counts={k:len(v) for k,v in required.items()},consumer_paths_unchanged=len(consumer),nested_payloads_verified=inner_counts,file_bytes_modes_mtimes_preserved=True,independent_files_without_hardlinks=True,ci_status=m['ci_status']),indent=2))
if __name__=='__main__':main()
