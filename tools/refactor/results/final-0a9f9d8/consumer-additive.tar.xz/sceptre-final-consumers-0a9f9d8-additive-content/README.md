# Final0a candidate consumer evidence: additive CAS

This bundle contains new consumer correctness evidence for candidate `0a9f9d879db6a52e3daef237daa1711b9d542976`. It requires the unchanged historical/pre-Air content store. Extract `sceptre-pre-air-evidence-content-dict256.tar.xz` (53,283,280bytes, SHA2567f4a2eaaacf43113e472bfb9dc8926e379f0a8eab60f36b70360781cff5e055e) and this additive archive, then run:

```
python3 restore.py /extracted/sceptre-pre-air-evidence-content /fresh/consumer-output
python3 restore.py /extracted/sceptre-pre-air-evidence-content /fresh/consumer-output --verify-only
```

The historical92MB archive contains the identical tar stream and is also a valid base. The restore script checks the exact base manifest and control-manifest hashes, every required base blob, every additive blob and every output file. Files are independent copies, never hardlinks. All per-file bytes, modes and nanosecond mtimes are preserved. No original absolute path, R, network, compiled installation or source checkout is needed to restore/inspect the evidence.

The unchanged original21 outputs were verified and reused, not re-executed. Their complete prior raw evidence remains under the base `consumers32/` prefix. Seven exact result/report objects are materialized in this additive output, with explicit source-path/hash authority. Historical32 candidate success is never relabeled as final0a evidence.

Final0a passes30/30 actual stages and complete standard/nuclear fair shared-arrival local Nextflow;15 selected book cells retain14pass and the same empty-barcode failure/exit1. All three ordered payload families and the response-pod plan compare exactly. Executed runner/helper/producer bytes, fixtures/book inputs, source/binding text, DLL/library/build readbacks, logs/work products and ordered RDS outputs are retained. No outputs were sorted. Consumer runtime was concurrent with other checks and does not establish uncontended resource performance. Whole-book rendering and other documented external runtime configurations remain unqualified.

Read the restored `COVERAGE.md`, `original-reuse.json`, `raw/execution-manifest.json` and `raw/acceptance-summary.json`. Precise exclusions are in `exclusions.json`. Two failed packaging-script attempts are retained as scripts/logs; they did not rerun or change consumer outputs. Duplicate partial package-copy trees are excluded because the final files are already retained. Final whole-package/platform/resource acceptance is separate.
