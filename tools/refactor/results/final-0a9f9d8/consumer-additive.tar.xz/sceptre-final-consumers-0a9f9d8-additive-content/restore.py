#!/usr/bin/env python3
"""Restore final0a consumer evidence using the REQUIRED immutable historical CAS.
Usage: python3 restore.py BASE_CONTENT_DIRECTORY FRESH_DESTINATION
       python3 restore.py BASE_CONTENT_DIRECTORY DESTINATION --verify-only
Verifies exact base manifest/control hashes and every required base/new object.
Creates independent regular files; requires only Python standard library.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,shutil,stat

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def safe(value):
 p=PurePosixPath(value)
 if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('Unsafe manifest path: '+value)
 return Path(*p.parts)
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('base',type=Path);a.add_argument('destination',type=Path);a.add_argument('--verify-only',action='store_true');args=a.parse_args()
 root=Path(__file__).resolve().parent;base=args.base.resolve();dest=args.destination.resolve()
 control=json.loads((root/'control-manifest.json').read_text())
 for e in control['files']:assert sha(root/safe(e['path']))==e['sha256']
 m=json.loads((root/'manifest.json').read_text());assert m['schema_version']==1
 assert sha(base/'manifest.json')==m['base_manifest_sha256'],'Wrong/mutated base manifest.'
 assert sha(base/'control-manifest.json')==m['base_control_manifest_sha256'],'Wrong/mutated base control manifest.'
 bm=json.loads((base/'manifest.json').read_text());bi={e['sha256']:e['bytes'] for e in bm['files']};bp={e['path']:e for e in bm['files']}
 required={e['sha256']:e['bytes'] for e in m['required_base_blobs']}
 assert required=={e['sha256']:e['bytes'] for e in m['files'] if e['store']=='base'}
 for digest,size in required.items():
  assert bi[digest]==size
  p=base/'blobs'/digest;assert p.is_file() and p.stat().st_size==size and sha(p)==digest,'Missing/mutated base object.'
 unique={e['sha256']:e['bytes'] for e in m['files'] if e['store']=='additive'}
 assert set(p.name for p in (root/'blobs').iterdir())==set(unique)
 for digest,size in unique.items():
  p=root/'blobs'/digest;assert p.is_file() and p.stat().st_size==size and sha(p)==digest
 assert len({e['path'] for e in m['files']})==len(m['files'])
 for e in m['files']:safe(e['path']);assert e['mode']&0o7000==0
 if not args.verify_only:
  if dest.exists() and any(dest.iterdir()):raise ValueError('Destination must be fresh and empty.')
  dest.mkdir(parents=True,exist_ok=True)
  for e in m['files']:
   p=dest/safe(e['path']);p.parent.mkdir(parents=True,exist_ok=True)
   object_root=base if e['store']=='base' else root
   shutil.copyfile(object_root/'blobs'/e['sha256'],p);p.chmod(e['mode']);os.utime(p,ns=(e['mtime_ns'],e['mtime_ns']))
 actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file() or p.is_symlink()}
 assert actual=={e['path'] for e in m['files']}
 for e in m['files']:
  p=dest/safe(e['path']);s=p.lstat()
  assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size==e['bytes'] and sha(p)==e['sha256']
  assert stat.S_IMODE(s.st_mode)==e['mode'] and s.st_mtime_ns==e['mtime_ns'],e['path']
 for e in m['original_reuse']:
  authority=bp[e['base_path']];assert authority['sha256']==e['sha256'] and authority['bytes']==e['bytes']
  p=dest/safe(e['restored_path']);assert sha(p)==e['sha256'] and p.stat().st_size==e['bytes']
 summary=json.loads((dest/'raw/acceptance-summary.json').read_text())
 assert summary['production_pin']==m['production_pin'] and summary['original_reexecuted'] is False
 assert summary['candidate_exit_status']=={'stages':0,'nextflow-arrival-controlled':0,'book':1}
 assert all(v['exact_payload'] for v in summary['comparisons'].values())
 print(json.dumps(dict(verified=True,production_pin=m['production_pin'],reference_pin=m['reference_pin'],original_reexecuted=False,
  files_verified=len(m['files']),base_manifest_sha256=m['base_manifest_sha256'],required_base_blobs_verified=len(required),new_blobs_verified=len(unique),
  original_result_objects_verified=len(m['original_reuse']),file_bytes_modes_mtimes_preserved=True,independent_files_without_hardlinks=True),indent=2))
if __name__=='__main__':main()
