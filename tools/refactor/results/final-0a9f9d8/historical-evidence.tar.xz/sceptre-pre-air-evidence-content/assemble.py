#!/usr/bin/env python3
"""Losslessly stage selected historical/pre-Air evidence in one SHA256 content store.
No R, compilation, network, consumer runtime, or production checkout mutations.
"""
from pathlib import Path, PurePosixPath
import collections, datetime, hashlib, json, os, re, shutil, stat, tarfile

TMP=Path('/private/tmp')
STAGE=TMP/'sceptre-pre-air-evidence-content'
ARCHIVE=TMP/'sceptre-pre-air-evidence-content.tar.xz'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')

def policy(group,rel):
    parts=rel.parts
    if group in ('final32','final2ab') and len(parts)>=2 and parts[0] in ('candidate','reference') and parts[1] in ('source','library'):
        return 'Extracted immutable package source is represented by source.tar' if parts[1]=='source' else 'Installed package library excluded; build/DLL fingerprints retained'
    if group=='score-remedy' and parts and parts[0] in ('source','reference-source','library'):
        return 'Extracted package source represented by retained source archive' if parts[0]!='library' else 'Installed package library excluded; build/DLL fingerprints retained'
    if group=='final32' and len(parts)>=3 and parts[1] in ('check','check-aligned'):
        if parts[2]=='source':return 'R CMD check extracted build source; immutable-source.tar retained'
        if len(parts)>=4 and parts[2]=='sceptre.Rcheck' and parts[3] in ('00_pkg_src','sceptre'):
            return 'Disposable R CMD check extracted-source or installed-package cache; logs/tests/example outputs retained'
    if any(p.endswith('.dSYM') for p in parts) or rel.suffix in ('.o','.so','.dll','.dylib','.a'):
        return 'Compiled object/shared library excluded; source, compile logs and identity fingerprints retained'
    if 'sourcecpp-cache' in parts and rel.name in ('cache.rds','token.rds'):
        return 'Disposable sourceCpp metadata cache; generated source and wrapper retained'
    return None

roots=[
 ('final32',TMP/'sceptre-final-32b2076'),
 ('final2ab',TMP/'sceptre-final-2ab3f5a'),
 ('native-cost',TMP/'sceptre-native-cost-32b2076'),
 ('score-remedy',TMP/'sceptre-score-loop-remedy-32b2076'),
 ('maintainability32',TMP/'sceptre-maintainability-final-32b2076-2zwn2v4i'),
 ('bioc32',TMP/'sceptre-bioccheck-final-32b2076-evidence'),
 ('consumers32',TMP/'sceptre-final-consumers-32b2076-reconstruction-verification/reconstructed'),
]
extra_names=[
 'sceptre-whole-package-review-32b2076.md','sceptre-whole-package-coverage-32b2076.json',
 'sceptre-score-loop-cost-independent-review.md','sceptre-score-loop-cost-independent-binding.json',
 'sceptre-triplet-memory-diagnostic-design-review.md','sceptre-triplet-memory-diagnostic-design-amendment.md',
 'sceptre-resource-triplet-causal.py','sceptre-storage-triage-32b2076.md',
 'sceptre-warm-path-source-triage-32b2076.md','sceptre-warm-path-repeat-source-triage-32b2076.md','sceptre-warm-path-preparation-rss-triage-32b2076.md',
 'sceptre-build-final-32b2076.py','sceptre-final-build-tarball-2ab3f5a.py','sceptre-final-2ab3f5a-build-driver.log',
 'sceptre-final-2ab3f5a-resource-driver.log','sceptre-final-installed-2ab3f5a.R','sceptre-final-native-2ab3f5a.py','sceptre-final-check-2ab3f5a.py',
 'sceptre-final-consumers-32b2076-receipt.json','sceptre-final-consumers-32b2076-integrity.json','sceptre-final-consumers-32b2076-content-receipt.json',
 'sceptre-final-consumers-candidate-only.py','sceptre-final-consumers.py','sceptre-final-consumers-finalize.py','sceptre-final-consumers-package.py',
]
extra_paths=[('reports-and-drivers/'+name,TMP/name) for name in extra_names]
for name in ['receipt.json','reconstruction.stdout.json','reconstruction.stderr.log','verification-only.stdout.json','verification-only.stderr.log']:
 extra_paths.append(('consumer-restore-receipts/'+name,TMP/'sceptre-final-consumers-32b2076-reconstruction-verification'/name))
for name in ['content-manifest.json','reconstruct.py']:
 extra_paths.append(('consumer-original-cas-control/'+name,TMP/'sceptre-final-consumers-32b2076-content'/name))

assert not STAGE.exists() and not ARCHIVE.exists()
STAGE.mkdir();(STAGE/'blobs').mkdir()
entries=[];directories={};exclusions=[];symlinks=[];source_stats={};secret_candidates=[]
secret_patterns=[('github_token',re.compile(rb'(?:github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,})')),
 ('openai_key',re.compile(rb'sk-(?:proj-)?[A-Za-z0-9_-]{35,}'))]

def metadata(p):
 s=p.lstat();return dict(mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,bytes=s.st_size)

def add_dir(target,p):
 m=metadata(p);directories[target]=dict(path=target,mode=m['mode'],mtime_ns=m['mtime_ns'])

def add_file(target,p,group,reason=None):
 m=metadata(p)
 if reason:
  exclusions.append(dict(path=target,original_path=str(p),reason=reason,**m));return
 if p.is_symlink():
  value=os.readlink(p);body=value.encode();digest=hashlib.sha256(body).hexdigest()
  symlinks.append(dict(path=target,original_path=str(p),target=value,sha256=digest,**m));return
 assert p.is_file(),str(p)
 digest=sha(p);assert metadata(p)==m,('Changed while reading',str(p))
 blob=STAGE/'blobs'/digest
 if not blob.exists():shutil.copyfile(p,blob);assert sha(blob)==digest
 entry=dict(path=target,original_path=str(p),sha256=digest,**m)
 entries.append(entry);source_stats[str(p)]=m
 if p.suffix in ('.json','.log','.md','.R','.py','.txt','.csv') and m['bytes']<=20*1024*1024:
  body=p.read_bytes()
  for kind,pat in secret_patterns:
   if pat.search(body):secret_candidates.append(dict(path=target,kind=kind))

for group,root in roots:
 assert root.is_dir(),str(root)
 add_dir(group,root)
 for current,ds,fs in os.walk(root,followlinks=False):
  current=Path(current)
  for name in ds[:]:
   p=current/name;rel=p.relative_to(root);target=group+'/'+str(rel)
   if p.is_symlink():
    add_file(target,p,group,policy(group,rel));ds.remove(name)
   elif not policy(group,rel):add_dir(target,p)
  for name in fs:
   p=current/name;rel=p.relative_to(root);add_file(group+'/'+str(rel),p,group,policy(group,rel))
for target,p in extra_paths:
 assert p.is_file(),str(p)
 add_file(target,p,'extra')
# No included path can have a symlink parent; restore never follows links while writing.
paths={x['path'] for x in entries};assert len(paths)==len(entries)
for x in symlinks:
 assert not any(p.startswith(x['path']+'/') for p in paths)
for p,m in source_stats.items():assert metadata(Path(p))==m,('Source changed during snapshot',p)
assert not secret_candidates,('Possible secret pattern requires private inspection',secret_candidates)
consumer_entries=[e for e in entries if e['path'].startswith('consumers32/')]
assert len(consumer_entries)==2128
original_manifest=TMP/'sceptre-final-consumers-32b2076-reconstruction-verification/reconstructed/artifact-manifest.json'
assert sha(original_manifest)=='369a5d2204957bc70029e7b86097850ca4e1aa1e884ebd3062fbe4cafe0dbe37'
expected=json.loads(original_manifest.read_text())['files'];assert len(expected)==2127
consumer_map={e['path'].removeprefix('consumers32/'):e for e in consumer_entries}
for e in expected:
 a=consumer_map[e['path']];assert a['sha256']==e['sha256'] and a['bytes']==e['bytes']

exclusion_notes=[
 'Installed package libraries, compiled objects/DLLs and R CMD check installed caches are excluded by explicit per-file records, not silently discarded.',
 'Complete Git/package source archives and R CMD build source tarballs are retained; their extracted full-package duplicates are excluded.',
 'Native original/transformed/sourceCpp generated .cpp/.h/.R, instrumentation and all R CMD check tests/logs/example outputs are retained.',
 'Maintainability selected-source and testability-source snippets are deliberately retained alongside their small archive to preserve analyzer input.',
 'All 2127 previously retained consumer payload files plus their original artifact manifest are retained byte-for-byte. Neither redundant full consumer archive nor the old 512-blob CAS tree is embedded; its payload is represented by this global CAS.',
 'No unrelated temporary trees, installed R/Java/Nextflow binaries, package caches, browser data, credentials or remote systems were collected.',
 'The 2ab3f5a resource evidence reuses the explicitly recorded original21 build. This bundle does not claim 2ab3f5a whole-suite/check/consumer/Bioc qualification.',
 'The consumer candidate-only driver is prepared tooling, not execution evidence for a post32 candidate.',
]
excluded_archive_refs=[]
for name in ['sceptre-final-consumers-32b2076-evidence.tar.gz','sceptre-final-consumers-32b2076-content.tar.xz']:
 p=TMP/name;excluded_archive_refs.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),reason='Redundant consumer container; every retained payload file and original control receipt is included in the global CAS'))
dump(STAGE/'exclusions.json',dict(schema_version=1,notes=exclusion_notes,excluded_files=exclusions,redundant_containers_not_embedded=excluded_archive_refs))
manifest=dict(schema_version=1,created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 authority='Historical/pre-Air evidence only; preserves failures and does not qualify a later final production pin.',
 source_pins=dict(reference='21f9ea098b69c444a884a49bc254de711968e3b5',historical32='32b2076b8ce6fd27cfa1a6326890342c241dbd27',postremedy_preAir='2ab3f5a (full pin in final2ab/candidate/build.json)'),
 collection_roots=[dict(label=g,original_path=str(p)) for g,p in roots],
 files=sorted(entries,key=lambda x:x['path']),symlinks=sorted(symlinks,key=lambda x:x['path']),directories=sorted(directories.values(),key=lambda x:x['path']),
 exclusions_sha256=sha(STAGE/'exclusions.json'),consumer_original_manifest_sha256=sha(original_manifest),
 consumer_original_file_count=2127,consumer_including_original_manifest_count=2128,
 secret_scan=dict(scope='High-confidence token patterns in selected text files only; no token values logged',potential_matches=0))
dump(STAGE/'manifest.json',manifest)
shutil.copy2(Path(__file__),STAGE/'assemble.py')
print(json.dumps(dict(stage=str(STAGE),included_files=len(entries),symlinks=len(symlinks),unique_blobs=len(list((STAGE/'blobs').iterdir())),
 logical_bytes=sum(e['bytes'] for e in entries),unique_bytes=sum(p.stat().st_size for p in (STAGE/'blobs').iterdir()),
 excluded_files=len(exclusions),excluded_bytes=sum(e['bytes'] for e in exclusions),
 group_counts=dict(collections.Counter(e['path'].split('/')[0] for e in entries)),manifest_sha256=sha(STAGE/'manifest.json')),indent=2),flush=True)
