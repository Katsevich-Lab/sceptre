#!/usr/bin/env python3
"""Restore and independently verify the historical/pre-Air evidence CAS.
Usage after extracting the archive:
  python3 restore.py /fresh/output
  python3 restore.py /existing/output --verify-only
Only Python standard library is required. No original paths, R, network or packages.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,shutil,stat

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def safe(value):
 p=PurePosixPath(value)
 if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('Unsafe path: '+value)
 return Path(*p.parts)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('destination',type=Path);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
 root=Path(__file__).resolve().parent;m=json.loads((root/'manifest.json').read_text())
 assert m['schema_version']==1 and sha(root/'exclusions.json')==m['exclusions_sha256']
 controls=json.loads((root/'control-manifest.json').read_text())
 for e in controls['files']:assert sha(root/safe(e['path']))==e['sha256']
 files=m['files'];links=m['symlinks'];dirs=m['directories']
 assert len({e['path'] for e in files+links})==len(files)+len(links)
 for e in files+links+dirs:
  safe(e['path']);assert e['mode']&0o7000==0
 dest=args.destination.resolve()
 if not args.verify_only:
  if dest.exists() and any(dest.iterdir()):raise ValueError('Destination must be fresh and empty.')
  dest.mkdir(parents=True,exist_ok=True)
  unique={e['sha256']:e['bytes'] for e in files}
  assert {p.name for p in (root/'blobs').iterdir()}==set(unique),'Unexpected/orphan blob.'
  for digest,size in unique.items():
   p=root/'blobs'/digest;assert p.is_file() and p.stat().st_size==size and sha(p)==digest
  for e in sorted(dirs,key=lambda x:len(PurePosixPath(x['path']).parts)):(dest/safe(e['path'])).mkdir(parents=True,exist_ok=True)
  for e in files:
   p=dest/safe(e['path']);p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'blobs'/e['sha256'],p);p.chmod(e['mode']);os.utime(p,ns=(e['mtime_ns'],e['mtime_ns']))
  for e in links:
   p=dest/safe(e['path']);p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(e['target']);os.utime(p,ns=(e['mtime_ns'],e['mtime_ns']),follow_symlinks=False)
  for e in sorted(dirs,key=lambda x:len(PurePosixPath(x['path']).parts),reverse=True):
   p=dest/safe(e['path']);p.chmod(e['mode']);os.utime(p,ns=(e['mtime_ns'],e['mtime_ns']))
 actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file() or p.is_symlink()}
 assert actual=={e['path'] for e in files+links},'Restored path set differs.'
 for e in files:
  p=dest/safe(e['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  assert s.st_size==e['bytes'] and sha(p)==e['sha256'] and stat.S_IMODE(s.st_mode)==e['mode'] and s.st_mtime_ns==e['mtime_ns'],e['path']
 for e in links:
  p=dest/safe(e['path']);s=p.lstat();assert p.is_symlink() and os.readlink(p)==e['target']
  assert hashlib.sha256(os.readlink(p).encode()).hexdigest()==e['sha256'] and s.st_mtime_ns==e['mtime_ns']
 for e in dirs:
  p=dest/safe(e['path']);s=p.lstat();assert stat.S_ISDIR(s.st_mode) and stat.S_IMODE(s.st_mode)==e['mode'] and s.st_mtime_ns==e['mtime_ns']
 # Independently honor the previously signed consumer manifest and Bioc payload manifest.
 consumer=dest/'consumers32';p=consumer/'artifact-manifest.json';assert sha(p)==m['consumer_original_manifest_sha256']
 old=json.loads(p.read_text());assert len(old['files'])==2127
 for e in old['files']:
  p=consumer/safe(e['path']);assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
 bioc=dest/'bioc32';b=json.loads((bioc/'manifest.json').read_text());assert len(b['files'])==76
 for e in b['files']:
  p=bioc/safe(e['path']);assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
 print(json.dumps(dict(verified=True,authority=m['authority'],payload_files_verified=len(files),symlinks_verified=len(links),directories_metadata_verified=len(dirs),unique_blobs=len({e['sha256'] for e in files}),consumer_original_paths_verified=2127,consumer_including_manifest_paths=2128,bioc_original_payloads_verified=76,file_bytes_modes_mtimes_preserved=True,independent_files_without_hardlinks=True),indent=2))
if __name__=='__main__':main()
