# Historical/pre-Air SCEPTRE evidence

This archive preserves historical evidence and its failures. It does not qualify a later final source pin or Air-formatted code. `manifest.json` maps every retained path to one SHA256-named object in `blobs/`, with original path, exact byte count, mode and nanosecond modification time. Identical content is stored once across all evidence families. `exclusions.json` lists each deliberately excluded file and reason; no retained logs or numerical outputs were summarized away.

Restore independently with Python's standard library:

```
python3 restore.py /fresh/output
python3 restore.py /fresh/output --verify-only
```

Both calls verify the archived controls and each reconstructed file. The first also verifies every content object and creates independent files, not hardlinks. Verification additionally follows the unchanged original 2,127-file consumer manifest and 76-payload Bioc manifest. Directory metadata is restored after file creation. Original absolute paths inside raw reports remain unchanged as provenance; they are not dependencies of restoration.

## Evidence authority

- `final32/`: frozen production `32b2076b8ce6fd27cfa1a6326890342c241dbd27`, original `21f9ea098b69c444a884a49bc254de711968e3b5`. Includes installed/native/oracle outputs, initial package-check failure and aligned successes, full resource matrix, confirmed counterbalanced regressions, invalidated first timing attempt, allocations/supplement, profile diagnosis, CI and build records, source archives and resource inputs. Failed/invalidated studies retain their original labels and outputs.
- `final2ab/`: pre-Air score-loop remedy `2ab3f5a2cf3d9f19242cbe8c419ada913aa721a8`, its complete resource matrix, quiet-window/build records, source archive and actual executed drivers. The original21 build is explicitly reused. This evidence does **not** assert 2ab whole-suite, package-check, consumer or Bioc qualification.
- `native-cost/`, `score-remedy/`: diagnosis and bounded actual-source remedy checks, source/header/probe evidence and failed stale-oracle attempts. Source arithmetic and original evidence are retained independently of compiled artifacts.
- `maintainability32/`, `bioc32/`: complete retained analyzer/testability inputs and raw metric outputs, small source archive, and all76 Bioc payloads plus the bundle's control records.
- `consumers32/`: every one of the previously retained2,127 consumer files plus their original artifact manifest. This is historical32 consumer correctness evidence, including30 actual stages, fair shared-arrival standard/nuclear Nextflow, and14/15 selected book cells with inherited empty-barcode error/nonzero exit preserved. It is not whole-book success or uncontended resource evidence. Original restore receipts/control bytes are retained under `consumer-*`.
- `reports-and-drivers/`: signed whole32 review/coverage, independent D-only review/binding, source-only storage/heap/triplet design reports and the reviewed initial/amended/current triplet causal prototypes. **Neither triplet causal prototype was executed.** Their reconstructed historical bytes match the recorded review hashes; the current hardcoded2ab driver is not adapted or qualified for final Air source. The future candidate-only consumer driver is prepared tooling, not an execution record.

## Exclusions and reproducibility

Installed libraries, compiled objects/DLLs, disposable Rcheck installed/source caches and sourceCpp metadata caches are excluded. Exact compile/source/DLL fingerprints and build logs are retained. Full extracted package-source duplicates are represented by their exact source archives. Generated probe sources/wrappers, Rcheck tests/logs/example outputs, selected maintainability source snippets, all numerical RDS, raw profiles and successful/failed attempt outputs are retained. The two redundant consumer tar containers and old consumer blob-store tree are not embedded because their complete retained payload is represented by the global CAS; their exact receipts remain unchanged.

`assemble.py` is the executed initial collection recipe; `supplement.py` adds the explicitly requested tiny provenance/runner records. The staged manifest is the authoritative final selection, including each exclusion. No production source, statistical outputs, tolerances, fixtures, runtime configuration or methods were changed to construct this archive. No new R/consumer execution occurred. A later final qualification can be added as a distinct manifest prefix using the same `blobs/` store while preserving this historical manifest and all existing objects.
