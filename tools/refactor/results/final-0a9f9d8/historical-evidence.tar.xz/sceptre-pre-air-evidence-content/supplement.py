#!/usr/bin/env python3
"""Add the explicitly requested tiny historical provenance/driver records to the staged CAS."""
from pathlib import Path
import hashlib,json,shutil,stat,datetime
root=Path(__file__).resolve().parent
p=root/'manifest.json';m=json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(target,path,expected=None):
 path=Path(path);s=path.stat();digest=sha(path)
 if expected:assert digest==expected
 blob=root/'blobs'/digest
 if not blob.exists():shutil.copyfile(path,blob)
 assert sha(blob)==digest
 old=[x for x in m['files'] if x['path']==target]
 if old and old[0]['sha256']!=digest:
  prior=dict(old[0]);prior['path']=target+'.initial-staging-snapshot';m['files'].append(prior)
 m['files']=[x for x in m['files'] if x['path']!=target]
 m['files'].append(dict(path=target,original_path=str(path),mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,bytes=s.st_size,sha256=digest))
add('reports-and-drivers/sceptre-resource-triplet-causal-initial-reviewed-54ae91bc.py','/private/tmp/sceptre-resource-triplet-causal-initial-reviewed-54ae91bc.py','54ae91bcf6220101f100772bc1c3f0e907e62e22646ca807ae4fcf801835e740')
add('reports-and-drivers/sceptre-resource-triplet-causal-reviewed-f03ad814.py','/private/tmp/sceptre-resource-triplet-causal-reviewed-f03ad814.py','f03ad814b0113d9edaa961882ad1f50e33dc2a07341486aba5a3dff7d1491901')
add('reports-and-drivers/sceptre-resource-triplet-causal.py','/private/tmp/sceptre-resource-triplet-causal.py')
add('reports-and-drivers/sceptre-triplet-diagnostic-prototype-provenance.json','/private/tmp/sceptre-triplet-diagnostic-prototype-provenance.json')
add('final2ab/executed-runners/sceptre-resource-final-counterbalanced.py','/private/tmp/sceptre-resource-final-counterbalanced.py')
add('final2ab/executed-runners/sceptre-final-candidate-build.py','/private/tmp/sceptre-final-candidate-build.py')
m['source_pins']['postremedy_preAir']=json.loads(Path('/private/tmp/sceptre-final-2ab3f5a/candidate/build.json').read_text())['source_commit']
m['triplet_prototype_scope']='Initial reviewed, amended reviewed and current causal prototypes were NOT executed. The historical reviewed bytes were mechanically recovered and matched recorded hashes. Hardcoded2ab assumptions do not qualify final Air code. See retained provenance.'
m['files'].sort(key=lambda x:x['path'])
m['supplemented_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
p.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
print('Supplemented',len(m['files']),'payload paths.')
