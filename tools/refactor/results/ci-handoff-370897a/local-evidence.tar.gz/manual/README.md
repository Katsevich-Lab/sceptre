# Refactor consistency comparison

Original: 21f9ea098b69c444a884a49bc254de711968e3b5
Candidate: 370897aa368d4a677fbc60d607364a7795465f2f

Result: passed
Passing expectations: 1265
Platform-qualified skips: 0

See checks.csv for per-contract results and compare.log/results.rds for test differences.
No expected output was regenerated from candidate source. This command is not CI.
