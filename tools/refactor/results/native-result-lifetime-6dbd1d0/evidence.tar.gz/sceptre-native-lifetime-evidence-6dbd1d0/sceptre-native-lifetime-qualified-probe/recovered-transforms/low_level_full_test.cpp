#include <Rcpp.h>
#include "/private/tmp/sceptre-native-lifetime-qualified-probe/inference.h"
#include "/private/tmp/sceptre-native-lifetime-qualified-source/src/sampling_safety.h"
#include "/private/tmp/sceptre-native-lifetime-qualified-source/src/result_lifetime.h"

using namespace Rcpp;


// Sole Rcpp association boundary. y/mu/a/w have n ordered fit cells and D is
// eigenbasis-rows x n (eigen() order); observed trt_idxs are R one-based positions and n_trt
// is their observed cardinality. Validate dimensions/positions/budget arithmetic
// before converting observed positions exactly once. Empty/degenerate numeric
// fits retain their existing NaN/Inf arithmetic rather than a new fallback.
// synthetic_idxs is a live worker-local XPtr owning a zero-based full DrawBank;
// validate its address, then borrow it const. Fixed-size tests use n_trt prefixes;
// CRT tests use each selected row's entire cardinality, including empty rows.
// Return the unchanged effect/score/tail schema, optionally the last selected
// null segment. Components allocate their own result and never mutate inputs
// or the bank; no RNG or file effects. This is not a persisted pointer format.
// [[Rcpp::export]]
SEXP run_association_test(NumericVector y,
                          NumericVector mu,
                          NumericVector a,
                          NumericVector w,
                          NumericMatrix D,
                          IntegerVector trt_idxs,
                          int n_trt,
                          bool use_all_cells,
                          SEXP synthetic_idxs,
                          int B1,
                          int B2,
                          int B3,
                          bool fit_parametric_curve,
                          bool return_resampling_dist,
                          int side_code) {
  sceptre::inference::check_score_dimensions(a, w, D);
  if (y.size() != a.size() || mu.size() != a.size())
    stop("Response, fitted means and score arrays must have aligned cell dimensions.");
  if (n_trt < 0 || trt_idxs.size() != n_trt)
    stop("Observed n_trt must equal the observed treatment position count.");
  for (int position : trt_idxs) {
    if (position < 1 || position > a.size())
      stop("Observed treatment position is outside the aligned cell range.");
  }
  sceptre::sampling::sum(sceptre::sampling::sum(B1, B2, "B1 + B2"), B3,
                         "B1 + B2 + B3");
  SEXP continuation;
  sceptre::inference::EffectEstimate effect;
  double z_orig;
  sceptre::inference::TailResult* owned_tail;
  {
    sceptre::ResultContinuation token;
    const sceptre::inference::DrawBank* bank;
    {
      // Finish owned Rcpp temporaries before allocating the native tail.
      const IntegerVector observed_positions =
        sceptre::inference::observed_positions_zero_based(trt_idxs);
      effect = sceptre::inference::estimate_effect(y, mu, observed_positions, n_trt);
      z_orig = sceptre::inference::observed_score(a, w, D, observed_positions);
      XPtr<sceptre::inference::DrawBank> draws(synthetic_idxs);
      if (draws.get() == nullptr) stop("Synthetic draw bank pointer is null.");
      bank = draws.get();
    }
    std::unique_ptr<sceptre::inference::TailResult> tail(new sceptre::inference::TailResult);
    *tail = sceptre::inference::evaluate_staged_tail(
      z_orig, a, w, D, n_trt, use_all_cells, *bank, B1, B2, B3,
      fit_parametric_curve, side_code);
    owned_tail = tail.release();
    continuation = token.release();
  }
  // No R operation or surviving compute owner in this transfer window.
  SEXP out = sceptre::inference::association_result_record(
    effect, z_orig, owned_tail, return_resampling_dist, continuation);
  UNPROTECT(1);
  return out;
}
