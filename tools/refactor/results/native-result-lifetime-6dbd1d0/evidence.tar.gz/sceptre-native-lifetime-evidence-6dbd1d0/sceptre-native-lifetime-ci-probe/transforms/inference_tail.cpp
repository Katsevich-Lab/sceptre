#include "/private/tmp/sceptre-native-lifetime-ci-probe/transforms/inference.h"
#include <boost/math/distributions/skew_normal.hpp>
#include <cmath>
#include <math.h>
#include <algorithm>

using namespace Rcpp;
using boost::math::skew_normal;

namespace sceptre {
namespace inference {

// Inclusive empirical exceedances with add-one numerator/denominator: side -1
// left, +1 right, otherwise twice the smaller tail. Ties count in both tails;
// two-sided p can exceed one and is intentionally not clamped. Empty segments
// retain the same formula. Scores are read only and no RNG is used.
double compute_empirical_p_value(const result_vector<double>& null_statistics, double z_orig, int side) {
  double p;
  if (side == -1 || side == 1) { // left or right
    double counter = 0;
    double B = (double) null_statistics.size();
    if (side == -1) { // left
      for (int i = 0; i < null_statistics.size(); i ++) if (z_orig >= null_statistics[i]) counter ++;
    } else { // right
      for (int i = 0; i < null_statistics.size(); i ++) if (z_orig <= null_statistics[i]) counter ++;
    }
    p = (1.0 + counter)/(1.0 + B);
  } else { // two-sided
    p = 2 * std::min(compute_empirical_p_value(null_statistics, z_orig, -1),
                     compute_empirical_p_value(null_statistics, z_orig, 1));
  }
  return p;
}


namespace {
// Moment fit on the selected segment: return location/scale/shape plus sample
// mean and population SD. Keep original moment/summation order: skewness >.995
// is replaced by .9*.995; no new symmetric cap or degenerate-fit repair. Nonfinite
// parameters are handled by the owning fitter's existing empirical fallback.
result_vector<double> fit_skew_normal_funct(const result_vector<double>& y) {
  // initialize variables
  int n = y.size();
  double MAX_GAMMA_1 = 0.995;
  double n_doub = (double) n, s_1 = 0, s_2 = 0, s_3 = 0;

  // compute mean and standard deviation
  for (int i = 0; i < n; i ++) {
    s_1 += y[i];
    s_2 += y[i] * y[i];
  }
  double m_y = s_1/n_doub;
  double sd_y = sqrt(s_2/n_doub - m_y * m_y);

  // compute gamma1
  for (int i = 0; i < n; i ++) {
    s_3 += pow(y[i] - m_y, 3);
  }
  double gamma1 = s_3/(n_doub * pow(sd_y, 3));
  if (gamma1 > MAX_GAMMA_1) gamma1 = 0.9 * MAX_GAMMA_1;

  // reparameterize solution
  double b = sqrt(2.0/M_PI);
  double r = std::copysign(1.0, gamma1) * pow(2 * std::abs(gamma1)/(4 - M_PI), 1.0/3.0);
  double delta = r/(b * sqrt(1 + r * r));
  double alpha = delta/sqrt(1 - delta * delta);
  double mu_z = b * delta;
  double sd_z = sqrt(1 - mu_z * mu_z);
  double omega = sd_y/sd_z;
  double xi = m_y - omega * mu_z;

  return result_vector<double> {xi, omega, alpha, m_y, sd_y};
}


// Goodness-of-fit check on an ascending right-tail representation (>=100).
// At probabilities .90,.905,...,.99, compare the recorded order statistic with
// fitted upper-tail probability; a ratio >2 declines the fit. The owning fitter
// supplies sorted/possibly sign-reflected data and enforces the length bound.
bool check_sn_tail(const result_vector<double>& y, double xi_hat, double omega_hat, double alpha_hat) {
  // The owning fitter checks n >= 100 before this internal .99 quantile lookup.
  // define variables
  double n = y.size(), ratio, quantile, p, sn_tail_prob;
  double RATIO_THRESH = 2.0;
  int idx;
  bool good_fit = true;

  // initialize the fitted skew normal distribution
  skew_normal dist(xi_hat, omega_hat, alpha_hat);

  // loop over the probabilities
  for (int i = 180; i < 199; i ++) {
    p = ((double) i)/200.0;
    idx = ceil(n * p);
    quantile = y[idx];
    sn_tail_prob = cdf(complement(dist, quantile));
    ratio = (1.0 - p)/sn_tail_prob;
    if (ratio > RATIO_THRESH) {
      good_fit = false;
      break;
    }
  }
  return good_fit;
}


// Existing two-tail extreme/normal-envelope ratio gate (threshold 1.5).
// Input is the nonempty ascending selected segment; endpoint ratios and even
// degenerate divisions retain original arithmetic. The const segment is neither
// sorted nor changed by this gate.
bool check_for_outliers (const result_vector<double>& null_statistics, double mu, double sd) {
  double min_z = null_statistics[0], max_z = null_statistics[null_statistics.size() - 1];
  double RATIO_THRESH = 1.5;
  double B = (double) null_statistics.size();
  double R_max = max_z/(mu + sd * sqrt(2 * log(B)));
  double R_min = min_z/(mu - sd * sqrt(2 * log(B)));
  bool ok = (R_max <= RATIO_THRESH && R_min <= RATIO_THRESH);
  return ok;
}

} // namespace

// Own the optional tail fit on a selected segment of at least 100 scores.
// Reject nonfinite moments/outliers/poor selected-tail fit with p=-1; stages
// then apply the existing empirical fallback. Accepted p uses requested side
// and is floored at 1e-250. Return xi/omega/alpha/p, even on a declined fit.
// Sorting is in place on this owned segment. A left-tail check reverses and
// reflects it, then restores signs only, so returned segment order can remain
// descending. Preserve that observable order; never touch the full draw bank.
// Short reached segments fail clearly; no RNG, R callbacks or file effects.
result_vector<double> fit_and_evaluate_skew_normal(double z_orig, result_vector<double>& null_statistics, int side_code) {
  if (null_statistics.size() < 100)
    stop("Reached skew-normal fitting requires at least 100 null statistics.");
  // 0. define variables
  double p = -1.0;
  bool finite_params = true;

  // 1. fit the skew normal
  result_vector<double> fitted_params = fit_skew_normal_funct(null_statistics);

  // 2. verify that the fitted parameters are finite
  for (int i = 0; i < fitted_params.size(); i ++) {
    if (!std::isfinite(fitted_params[i])) finite_params = false;
  }

  if (finite_params) {
    // 3. sort the vector of null statistics
    sort(null_statistics.begin(), null_statistics.end(), std::less<double>());

    // 4. compute the median of the null statistics
    int median_idx = (null_statistics.size() - 1)/2;
    double median = null_statistics[median_idx];

    // 5. determine the tail to check; if z_orig >= median, right; else, left
    bool check_right_tail = (z_orig >= median);
    bool outlier_ok, fit_ok = false, use_sn;

    // 6. check for outliers in both tails
    outlier_ok = check_for_outliers(null_statistics, fitted_params[3], fitted_params[4]);

    // 7. check for goodness of fit in the appropriate tail
    if (outlier_ok) {
      if (check_right_tail) { // right tail check
        fit_ok = check_sn_tail(null_statistics, fitted_params[0], fitted_params[1], fitted_params[2]);
      } else { // left tail check
        std::reverse(null_statistics.begin(), null_statistics.end());
        for (int i = 0; i < null_statistics.size(); i ++) null_statistics[i] *= -1.0; // flip sign
        fit_ok = check_sn_tail(null_statistics, -fitted_params[0], fitted_params[1], -fitted_params[2]);
        for (int i = 0; i < null_statistics.size(); i ++) null_statistics[i] *= -1.0; // flip sign back
      }
    }

    // 8. compute the SN p-value (using the appropriate tail) if there are no outliers and the fit is OK
    use_sn = outlier_ok && fit_ok;
    if (use_sn) {
      skew_normal dist(fitted_params[0], fitted_params[1], fitted_params[2]);
      if (side_code == 0) { // two-tailed
        p = 2.0 * (check_right_tail ? cdf(complement(dist, z_orig)) : cdf(dist, z_orig));
      } else if (side_code == 1) { // right-tailed
        p = cdf(complement(dist, z_orig));
      } else { // left-tailed
        p = cdf(dist, z_orig);
      }
      if (p <= 1.0e-250) p = 1.0e-250;
    }
  }
  // 9. return p, xi, omega, alpha
  return result_vector<double> {fitted_params[0], fitted_params[1], fitted_params[2], p};
}

} // namespace inference
} // namespace sceptre
