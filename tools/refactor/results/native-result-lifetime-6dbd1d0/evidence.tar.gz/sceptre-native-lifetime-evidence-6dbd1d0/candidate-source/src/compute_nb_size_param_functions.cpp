// [[Rcpp::depends(BH)]]

#include <Rcpp.h>
#include <boost/math/special_functions/digamma.hpp>
#include <boost/math/special_functions/trigamma.hpp>
#include <math.h>
#include <stdexcept>
using namespace Rcpp;

// Size theta uses Var(Y | mu) = mu + mu^2/theta. The R fitter supplies fixed
// Poisson fitted means in the same cell view as y; this is dispersion estimation,
// not a second joint negative-binomial coefficient fit. R owns final clipping.

// Negative-binomial size score for aligned response/mean vectors at trial th.
// Uses the existing Boost double special-function policy; domain/overflow can
// throw to the estimator's numerical boundary. Inputs are read only, no RNG.
double nb_score(double th, NumericVector mu, NumericVector y) {
  double sum = 0;
  for (int i = 0; i < mu.size(); i ++) {
    sum += boost::math::digamma(th + y[i]) - boost::math::digamma(th) + std::log(th) + 1 - std::log(th + mu[i]) - (y[i] + th)/(mu[i] + th);
  }
  return(sum);
}


// Matching observed information at th, with the same alignment/error contract
// as nb_score. Keep summation and special-function order for numerical parity.
double nb_info(double th, NumericVector mu, NumericVector y) {
 double sum = 0;
  for (int i = 0; i < mu.size(); i ++) {
    sum += boost::math::trigamma(th) - boost::math::trigamma(th + y[i]) - 1/th + 2/(mu[i] + th) - (y[i] + th)/((mu[i] + th) * (mu[i] + th));
  }
  return(sum);
}


// Existing moment pilot n / sum((y/mu - 1)^2); zero/nonfinite arithmetic is
// retained. The estimator evaluates this before its MLE/MM try boundary.
double nb_theta_pilot_est(NumericVector y, NumericVector mu) {
  double n = (double) y.size();
  double denom = Rcpp::sum((y/mu - 1) * (y/mu - 1));
  return(n/denom);
}


// Moment iteration from the supplied pilot and degrees of freedom. Returns
// {last theta, warning flag}; negative/nonfinite theta or reaching limit warns.
// Arithmetic/convergence rules are retained; the caller decides pilot fallback.
std::vector<double> nb_theta_mm(double t0, NumericVector y, NumericVector mu, double dfr, int limit, double eps) {
  int it = 0;
  double del = 1;
  while (++it < limit && fabs(del) > eps) {
    t0 = fabs(t0);
    // Match the Pearson residual sum to the supplied residual degrees of
    // freedom. Keep the existing step denominator and absolute-value restart;
    // neither a warning nor an exceptional step selects a new estimator here.
    del = (Rcpp::sum(Rcpp::pow(y - mu, 2)/(mu + Rcpp::pow(mu, 2)/t0)) - dfr)/Rcpp::sum(Rcpp::pow(y - mu, 2)/Rcpp::pow(mu + t0, 2));
    t0 -= del;
  }

  double warning = 0.0;
  if (t0 < 0 || it == limit || !std::isfinite(t0)) warning = 1.0;
  std::vector<double> out { t0, warning };
  return(out);
}


// Score/information iteration from the supplied pilot, returning {theta, warning}
// with the same warning convention as MM. Numeric exceptions propagate to the
// estimator; no response/mean mutation, random draws or file effects occur.
std::vector<double> nb_theta_mle(double t0, NumericVector y, NumericVector mu, int limit, double eps) {
  int it = 0;
  double del = 1;

  while (++it < limit && fabs(del) > eps) {
    t0 = fabs(t0);
    // Observed information is minus the score derivative, hence the plus
    // Newton step. Do not reorder its cell sums or change the stopping test.
    del = nb_score(t0, mu, y)/nb_info(t0, mu, y);
    t0 += del;
  }

  double warning = 0.0;
  if (t0 < 0 || it == limit || !std::isfinite(t0)) warning = 1.0;
  std::vector<double> out { t0, warning };
  return(out);
}


// Aligned response/mean vectors and the existing degrees-of-freedom, iteration
// and tolerance controls produce (estimate, method): 1 MLE, 2 MM, 3 pilot.
// Method records the existing committed branch, not a convergence guarantee:
// e.g. an MM exception leaves the preceding warning-bearing MLE state/method 1.
// Keep the whole MLE/MM try boundary and assignment order: a numerical failure
// during MM retains the already committed MLE state. Only the reached Boost
// domain/overflow failures are suppressed; allocation/system failures propagate.
// Pilot computation and result allocation remain outside this boundary.
// [[Rcpp::export]]
List estimate_theta(NumericVector y, NumericVector mu, double dfr, int limit, double eps) {
  // first, attempt to estimate theta via MLE
  double t0 = nb_theta_pilot_est(y, mu);
  double estimate = t0;
  int method = 3;
  try {
    std::vector<double> out = nb_theta_mle(t0, y, mu, limit, eps);
    estimate = out[0];
    method = 1;
    // A numerical warning selects MM from the original pilot (not the last
    // MLE iterate). A second warning restores that pilot and method 3.
    if (out[1] > 0.5) {
      out = nb_theta_mm(t0, y, mu, dfr, limit, eps);
      estimate = out[0];
      method = 2;
      if (out[1] > 0.5) {
        estimate = t0;
        method = 3;
      }
    }
    // return both the estimate and method indicator
  } catch (const std::domain_error&) {
  } catch (const std::overflow_error&) {}
  return(List::create(estimate, method));
}
