runs <- c(qualification = "/private/tmp/sceptre-native-lifetime-qualification",
          qualified = "/private/tmp/sceptre-native-lifetime-qualified")
recoveries <- list()
for (label in names(runs)) {
    prefix <- runs[[label]]
    root <- paste0(prefix, "-source")
    output <- paste0(prefix, "-probe")
    e <- readRDS(file.path(output, "result-ownership-results.rds"))
    relative <- c("src/inference.h", "src/inference_scores.cpp", "src/inference_tail.cpp",
        "src/inference_stages.cpp", "src/negative_control_functions.cpp", "src/low_level_full_test.cpp")
    source_files <- file.path(root, relative)
    generated <- file.path(output, basename(source_files))
    recovered <- file.path(output, "recovered-transforms", basename(source_files))
    dir.create(dirname(recovered[[1L]]), showWarnings = FALSE)
    for (i in seq_along(source_files)) {
        text <- readLines(source_files[[i]])
        text <- gsub("std::vector<", "result_vector<", text, fixed = TRUE)
        text <- gsub("std::unordered_set<", "result_set<", text, fixed = TRUE)
        for (name in c("TailResult", "CalibrationPairResult")) {
            needle <- paste0("struct ", name, " {")
            if (any(grepl(needle, text, fixed = TRUE)))
                text <- sub(needle, paste0(needle, "\n  ResultPayloadLifetime probe_lifetime;"), text, fixed = TRUE)
        }
        for (header in c("inference.h", "result_lifetime.h", "sampling_safety.h", "pair_eligibility.h")) {
            resolved <- if (header == "inference.h") generated[[1L]] else file.path(root, "src", header)
            text <- sub(paste0('#include "', header, '"'),
                        paste("#include", encodeString(resolved, quote = '"')), text, fixed = TRUE)
        }
        writeLines(text, recovered[[i]])
    }
    expected <- unname(e$generated_files_md5[generated])
    actual <- unname(tools::md5sum(recovered))
    stopifnot(identical(expected, actual))
    bridge <- file.path(output, "result-ownership-instrumented.cpp")
    stopifnot(identical(unname(tools::md5sum(bridge)), unname(e$generated_files_md5[bridge])))
    recoveries[[label]] <- list(reason = "Runner final source copy overwrote generated source basenames after successful execution; exact compiled transforms reconstructed.",
        original_generated_paths = generated, retained_recovery_paths = recovered,
        expected_md5_recorded_before_copy = expected, recovered_md5 = actual,
        all_six_equal = TRUE, bridge_unchanged = TRUE,
        generated_file_sha256 = vapply(recovered, function(p) digest::digest(file = p, algo = "sha256"), ""),
        result_rds_sha256 = digest::digest(file = file.path(output, "result-ownership-results.rds"), algo = "sha256"))
}
jsonlite::write_json(recoveries, "/private/tmp/sceptre-result-transform-recovery.json",
    pretty = TRUE, auto_unbox = TRUE)
print(vapply(recoveries, function(x) x$all_six_equal, logical(1)))
