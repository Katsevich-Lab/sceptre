# Native exact-result lifetime boundary (design for review)

Source base: dc093d27acefd2b3897eaf8b5a0bb4e9cbe7282f. This is a proposed narrow repair, not runtime qualification.

## Failure and chosen ordering

R allocations can jump past ordinary C++ destructors. Calibration groups currently own an unordered set while constructing their R matrix; calibration pairs own their result vectors and permutation while constructing their R list; association tests own their selected null-statistic segment while constructing their R record. These are existing defects, independent of the CL4 names.

Groups can allocate their exact matrix and cache its writable pointer before H/sample exist. The unchanged rejection/draw/order loops then run inside an allocation-free-from-R native scope, which ends before return.

For pairs and inference the selected output size is known only after native computation. Eager capacity is rejected: rejected pair requests should not allocate four maximum result buffers, and a stage1 result must not allocate an unreached B3 segment. Instead:

1. Validate and materialize all R inputs. PROTECT a public R_MakeUnwindCont token before the native result payload exists.
2. Compute under a unique_ptr in an ordinary C++ scope, outside any R_UnwindProtect callback. All existing C++ failure paths and bad_alloc unwind normally. Preserve all draw/math/loop ordering.
3. Release the payload to a raw pointer and end the entire native/unique_ptr/temporary-Rcpp scope normally. Only trivial scalar context construction follows; no R allocation, preservation, materialization or wrapper conversion intervenes.
4. Call public R_UnwindProtect with the preprovided token, a file-local raw-C-API exact-size leaf, and a noexcept allocation-free cleanup. The leaf owns no native/precious C++ objects and never C++-throws. It uses only raw SEXP/PROTECT, R allocation/name/attribute calls and primitive copying.
5. Cleanup deletes exactly one native result payload on both normal and R-jump exits, before R continues the original jump or before any final generated-wrapper conversion. On success the continuation roots the result until the token is unprotected immediately before the SEXP return.

The pair payload contains exactly its four grown accepted-result vectors; the tail payload contains the current TailResult, including only the reached/selected segment. No bank is copied. The extra ownership mechanism costs one small payload object and one precreated continuation token, not a budget-sized scratch buffer.

## API support and evidence

DESCRIPTION supports R>=4.1 and Rcpp>=1.0.9. The direct R API is publicly declared in R4.1 Rinternals.h and needs neither a new Rcpp version nor its optional RCPP_USING_UNWIND_PROTECT macro. Rcpp::unwindProtect is deliberately not used: it can allocate/preserve its own continuation while owners exist and introduces a C++ exception continuation bridge.

Verified official source copies/hashes: /private/tmp/sceptre-native-output-design-sources/source-manifest.json. In R4.1 context.c lines914-955, a nonNULL token skips the only token-creation branch, begincontext is a stack/field setup, SETJMP precedes the leaf, and cleanup runs after endcontext but before R_ContinueUnwind. The leaf does not install handlers/on.exit actions. No C++ exception crosses these R frames.

## Bounded qualification

Use actual source with test-only native allocator/lifetime instrumentation and R API interposition, unchanged owner scopes. Enumerate successful outputs and all observed R boundaries (including continuation creation, materialization, names/attributes, output and final copy/preserve). Inject raw R errors only at unowned or cleanup-protected boundaries; assert zero live native result/scratch blocks and exactly-once payload cleanup after each. Enumerate native bad_alloc points only in compute outside R frames. An unsafe ordering negative control fails via a C++ exception before any deliberate raw jump/leak. No actual OOM. Cover accepted and all-rejected pairs, ordinary/reached-stage tail variants and stage1 with a huge unused B3 to prove no eager budget allocation. Compare ordinary installed outputs, full banks, frozen fixture contracts and RNG under the existing independent original oracle separately. The probe only qualifies these native ownership scopes, not universal Rcpp/OOM safety.
