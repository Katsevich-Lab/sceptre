
<!-- README.md is generated from README.Rmd. Please edit that file -->

# sceptre <img src="man/figures/logo.png" align="right" width="150" alt="sceptre hex sticker" />

<!-- badges: start -->

[![R-CMD-check](https://img.shields.io/github/actions/workflow/status/Katsevich-Lab/sceptre/check-standard.yaml?branch=main&cacheSeconds=30)](https://github.com/Katsevich-Lab/sceptre/actions?query=workflow%3AR-CMD-check+branch%3Amain)
<!-- badges: end -->

`sceptre` implements an analysis pipeline for single-cell CRISPR screen
(i.e., Perturb-seq) data, including data import, gRNA-to-cell
assignment, quality control, and testing association between CRISPR
perturbations and changes in gene expression. It is built on three
principles:

- **Statistical rigor.** Association testing is built on a principled
  resampling-based methodology. Built-in calibration and power checks
  let you verify that false positives are controlled and that real
  effects are detectable — on your own data.
- **Massive scalability.** Optimized C++ routines improve performance.
  Optional [disk-backed data
  structures](https://cran.r-project.org/package=ondisc) allow the
  analysis of datasets too large to fit in memory. The companion
  [`sceptre` Nextflow
  pipeline](https://github.com/timothy-barry/sceptre-pipeline)
  distributes analyses across hundreds of processors on a cluster or
  cloud.
- **Ease of use.** A small, pipe-friendly set of functions takes you
  from raw count matrices to results in a handful of steps.

## Installation

Install the development version of `sceptre` from GitHub:

``` r
# install.packages("remotes")
remotes::install_github("Katsevich-Lab/sceptre")
```

## Documentation

New to `sceptre`? [Get
started](https://katsevich-lab.github.io/sceptre/articles/sceptre.html)
offers a brief tour of the pipeline, with plots and explanation at each
step. Other resources are the [function
reference](https://katsevich-lab.github.io/sceptre/reference/index.html)
and the comprehensive [`sceptre`
manual](https://timothy-barry.github.io/sceptre-book/).

## Project roadmap and community

`sceptre` is maintained as an open-source research-software project. The
current [roadmap](ROADMAP.md) describes the package’s technical and
sustainability priorities. Please read the [contribution
guide](CONTRIBUTING.md), [governance model](GOVERNANCE.md), and [Code of
Conduct](CODE_OF_CONDUCT.md) before contributing. The [support
guide](SUPPORT.md) explains where to ask questions, report bugs, and
request features.

## Featured publications

- [Barry et al.,
  2024](https://link.springer.com/article/10.1186/s13059-024-03254-2).
  “Robust differential expression testing…”. *Genome Biology*.
- [Barry et al.,
  2024](https://timothy-barry.github.io/biostatistics_2024.pdf).
  “Exponential family measurement error models…”. *Biostatistics.*
- [Morris et al.,
  2023](http://sanjanalab.org/reprints/Morris_Science_2023.pdf).
  “Discovery of target genes and pathways…”. *Science*.
- [Barry et al.,
  2021](https://link.springer.com/article/10.1186/s13059-021-02545-2).
  “SCEPTRE improves calibration and sensitivity…”. *Genome Biology*.

`sceptre` is also featured in a [10x Genomics analysis
guide](https://www.10xgenomics.com/analysis-guides/single-cell-crispr-screen-analysis-with-sceptre).
