## ----install, eval=FALSE------------------------------------------------------
# install.packages("devtools")
# devtools::install_github("katsevich-lab/sceptre")

## ----library, message=FALSE---------------------------------------------------
library(sceptre)

## ----schematic, out.width = "650px", fig.align="center", echo = FALSE, fig.cap=c("Standard `sceptre` pipeline")----
knitr::include_graphics("pipeline_schematic.png")

## ----setup, echo = FALSE------------------------------------------------------
library(Matrix)
output_directory <- file.path(tempdir(), "sceptre_outputs")
unlink(output_directory, recursive = TRUE, force = TRUE)

## ----minimal-example-shown, eval=FALSE----------------------------------------
# # load the data, creating a sceptre_object
# directories <- paste0(
#     system.file("extdata", package = "sceptre"),
#     "/highmoi_example/gem_group_",
#     1:2
# )
# data(grna_target_data_frame_highmoi)
# sceptre_object <- import_data_from_cellranger(
#     directories = directories,
#     moi = "high",
#     grna_target_data_frame = grna_target_data_frame_highmoi
# )
# 
# # construct the grna-gene pairs to analyze
# positive_control_pairs <- construct_positive_control_pairs(sceptre_object)
# discovery_pairs <- construct_cis_pairs(
#     sceptre_object,
#     positive_control_pairs = positive_control_pairs
# )
# 
# # apply the pipeline functions to the sceptre_object in order
# sceptre_object <- sceptre_object |> # |> is R's base pipe, similar to %>%
#     set_analysis_parameters(discovery_pairs, positive_control_pairs) |>
#     run_calibration_check() |>
#     run_power_check() |>
#     run_discovery_analysis()
# 
# # write the results to disk
# output_directory <- file.path(tempdir(), "sceptre_outputs")
# write_outputs_to_directory(sceptre_object, output_directory)
# 
# # open the output directory to inspect the results
# browseURL(output_directory)

## ----minimal-example-run, echo=FALSE, message=FALSE, results = "hide"---------
# load the data, creating a sceptre_object
directories <- paste0(
    system.file("extdata", package = "sceptre"),
    "/highmoi_example/gem_group_",
    1:2
)
data(grna_target_data_frame_highmoi)
sceptre_object <- import_data_from_cellranger(
    directories = directories,
    moi = "high",
    grna_target_data_frame = grna_target_data_frame_highmoi
)

# construct the grna-gene pairs to analyze
positive_control_pairs <- construct_positive_control_pairs(sceptre_object)
discovery_pairs <- construct_cis_pairs(
    sceptre_object,
    positive_control_pairs = positive_control_pairs
)

# apply the pipeline functions to the sceptre_object in order
sceptre_object <- sceptre_object |> # |> is R's base pipe, similar to %>%
    set_analysis_parameters(discovery_pairs, positive_control_pairs) |>
    run_calibration_check(print_progress = FALSE) |>
    run_power_check(print_progress = FALSE) |>
    run_discovery_analysis(print_progress = FALSE)

## ----print-discoveries, echo = FALSE------------------------------------------
# print a subset of the discovery results
sceptre_object |>
    get_result("run_discovery_analysis") |>
    dplyr::filter(significant) |>
    dplyr::select(grna_target, response_id, p_value, log_2_fold_change) |>
    dplyr::as_tibble() |>
    print(n = 5)

## ----directories--------------------------------------------------------------
directories <- paste0(
    system.file("extdata", package = "sceptre"),
    "/highmoi_example/gem_group_",
    1:2
)
directories # file paths to the example data on your computer

## ----list-files---------------------------------------------------------------
list.files(directories[1])
list.files(directories[2])

## ----load-grna-target-df------------------------------------------------------
data(grna_target_data_frame_highmoi)
grna_target_data_frame_highmoi[c(1:4, 11:14, 51:54), ]

## ----set-moi------------------------------------------------------------------
moi <- "high"

## ----import, results='hide', message=FALSE------------------------------------
sceptre_object <- import_data_from_cellranger(
    directories = directories,
    grna_target_data_frame = grna_target_data_frame_highmoi,
    moi = moi
)

## ----print-object-------------------------------------------------------------
sceptre_object

## ----pos-control-pairs--------------------------------------------------------
positive_control_pairs <- construct_positive_control_pairs(sceptre_object)
head(positive_control_pairs)

## ----discovery-pairs----------------------------------------------------------
discovery_pairs <- construct_cis_pairs(
    sceptre_object = sceptre_object,
    positive_control_pairs = positive_control_pairs,
    distance_threshold = 5e6
)
discovery_pairs[c(1:4, 101:104), ]

## ----set-side-----------------------------------------------------------------
side <- "left"

## ----set-analysis-params, message=FALSE, results='hide'-----------------------
sceptre_object <- set_analysis_parameters(
    sceptre_object = sceptre_object,
    discovery_pairs = discovery_pairs,
    positive_control_pairs = positive_control_pairs,
    side = side
)
print(sceptre_object) # output suppressed for brevity

## ----plot-grna-counts-shown, eval=FALSE---------------------------------------
# plot_grna_count_distributions(sceptre_object)

## ----plot-grna-counts, out.width = "650px", fig.align="center", echo = FALSE, fig.cap=c("Histograms of the gRNA count distributions")----
set.seed(2)
p <- plot_grna_count_distributions(sceptre_object = sceptre_object)
ggplot2::ggsave(
    filename = "grna_count_distribution.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 5,
    height = 4,
    dpi = 330
)
knitr::include_graphics("grna_count_distribution.png")

## ----assign-grnas, results='hide', message=FALSE------------------------------
sceptre_object <- assign_grnas(sceptre_object = sceptre_object)
print(sceptre_object) # output suppressed for brevity

## ----plot-assignments-shown, eval=FALSE---------------------------------------
# plot(sceptre_object)

## ----plot-assignments, out.width = "650px", fig.align="center", echo = FALSE, fig.cap=c("gRNA-to-cell assignments")----
set.seed(3)
p <- plot(sceptre_object)
ggplot2::ggsave(
    filename = "grna_count_assignments.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 5,
    height = 4,
    dpi = 330
)
knitr::include_graphics("grna_count_assignments.png")

## ----run-qc, results='hide'---------------------------------------------------
sceptre_object <- run_qc(sceptre_object, p_mito_threshold = 0.075)
print(sceptre_object) # output suppressed for brevity

## ----plot-qc-shown, eval=FALSE------------------------------------------------
# plot(sceptre_object)

## ----plot-qc, out.width = "450px", fig.align="center", echo = FALSE, fig.cap=c("Cellwise and pairwise quality control")----
p <- plot(sceptre_object)
ggplot2::ggsave(
    filename = "qc.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 4,
    height = 4.5,
    dpi = 330
)
knitr::include_graphics("qc.png")

## ----run-calibration-check, results='hide', message=FALSE---------------------
sceptre_object <- run_calibration_check(sceptre_object)
print(sceptre_object) # output suppressed for brevity

## ----plot-calibration-shown, eval=FALSE---------------------------------------
# plot(sceptre_object)

## ----plot-calibration, out.width = "650px", fig.align="center", echo = FALSE, fig.cap=c("Calibration check results")----
set.seed(3)
p <- plot(sceptre_object)
ggplot2::ggsave(
    filename = "calibration_check.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 5,
    height = 4,
    dpi = 330
)
knitr::include_graphics("calibration_check.png")

## ----run-power-check, results='hide', message=FALSE---------------------------
sceptre_object <- run_power_check(sceptre_object)
print(sceptre_object) # output suppressed for brevity

## ----plot-power-shown, eval=FALSE---------------------------------------------
# plot(sceptre_object)

## ----plot-power, out.width = "550px", fig.align="center", echo = FALSE, fig.cap=c("Power check results")----
set.seed(3)
p <- plot(sceptre_object)
ggplot2::ggsave(
    filename = "power_check.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 4,
    height = 3,
    dpi = 330
)
knitr::include_graphics("power_check.png")

## ----run-discovery, results='hide', message=FALSE-----------------------------
sceptre_object <- run_discovery_analysis(sceptre_object)
print(sceptre_object) # output suppressed for brevity

## ----plot-discovery-shown, eval=FALSE-----------------------------------------
# plot(sceptre_object)

## ----plot-discovery, out.width = "650px", fig.align="center", echo = FALSE, fig.cap=c("Discovery analysis results")----
set.seed(3)
p <- plot(sceptre_object)
ggplot2::ggsave(
    filename = "discovery_analysis.png",
    plot = p,
    device = "png",
    scale = 1.1,
    width = 5,
    height = 4,
    dpi = 330
)
knitr::include_graphics("discovery_analysis.png")

## ----write-outputs, results='hide'--------------------------------------------
write_outputs_to_directory(
    sceptre_object = sceptre_object,
    directory = output_directory
)

## ----list-output-files--------------------------------------------------------
list.files(output_directory)

## ----get-result---------------------------------------------------------------
result <- get_result(
    sceptre_object = sceptre_object,
    analysis = "run_discovery_analysis"
)

## ----head-result--------------------------------------------------------------
head(result)

## ----session-info-------------------------------------------------------------
library(sessioninfo)
session_info()

